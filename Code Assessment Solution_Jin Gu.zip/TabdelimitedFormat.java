/*
 * Class for changing tab-delimited format into Product format.
 */

public class TabdelimitedFormat implements FormatConverter{
	
	public Product  changeToProduct(String oringalData) {
		return new Product("", "", 0);
	}
}
