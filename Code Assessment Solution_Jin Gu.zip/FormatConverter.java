/*
 * Interface for changing different format into Product format.
 */
public interface FormatConverter {
	
	public Product changeToProduct(String oringalData);

}
