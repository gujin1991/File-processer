/*
 * We can use ellipse function to solve the problem. First initialize the  
 * grid with '-'. Then we draw the first ellipse, if we found the grid
 * elements in this ellipse, we mark it as 'x'. Finally we draw the second
 * ellipse, if we found the grid element is in the second ellipse, we clear
 * it as '-'. Just Like we draw two ellipses, then we remove the overlap
 * between them.
 * 
 * Assumption 1: the aspect ratio should be 2:1.
 * Assumption 2: width must be larger than 1.
 * Assumption 3: the center point of first ellipse is (width / 2, height / 2).
 * Assumption 4: the center point of second ellipse is (width * 4 / 5, height).
 */

public class Swoosh {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Swoosh swoosh = new Swoosh();
		swoosh.drawSwoosh(16);
		
	}
	
	/*
	 * drawSwoosh - Given the width of a window, draw a swoosh which
	 * its height adjust to maintain aspect ratio and there is no
	 * wasted rows/columns.
	 */
	public void drawSwoosh(int width) {
		if(width < 2) {
			System.out.println("The width is too small!");
			return;
		}
		
		int height = width / 2;
		char[][] grid = new char[height][width];
		/* Make all the grid elements to be '-' */
		init(grid);
		
		/* The center point coordinates of two ellipses */
		double x0 = (double)width / 2;
		double y0 = (double)height / 2;
		double x1 = (double)width * 4 / 5;
		double y1 = (double)height;
		
		/* Draw two ellipses */
		buildEllipse(grid, x0, y0, 0);
		buildEllipse(grid, x1, y1, 1);
		display(grid);
		
	}
	
	/*
	 * buildEllipse - check the grid elements to see whether they should be 'x'
	 * or '-'. If type is 0, and the point is in the ellipse, make it 'x'. Then
	 * if type is 1, and the points is in the ellipse, make it '-'; 
	 */
	private void buildEllipse(char[][] grid, double x, double y, int type) {
		// TODO Auto-generated method stub
		int height = grid.length;
		int width = grid[0].length;
		for(int i = 0; i < height; i++) {
			for(int j = 0; j < width; j++) {				
				if(inEllipse((double)j, x, (double)i, y, 
						((double)width / 2 + 1), ((double)height / 2 + 1))) {
					if(type == 0) {
						grid[i][j] = 'x';						
					} else {
						grid[i][j] = '-';						
					}
				}
			}
		}
		
	}
	
	/*
	 * inEllipse - check whether the given point (x, y) is in the ellipse or 
	 * not by a function.
	 */
	private boolean inEllipse(double x, double x0, double y, double y0, 
			double a, double b) {
		double a2 = a * a;
		double b2 = b * b;
		
		return ((x - x0) * (x - x0) * b2 + (y - y0) * (y - y0) * a2) < (a2 * b2);
		
	}

	/*
	 * display - display the elements on the grid.
	 */
	private void display(char[][] grid) {
		// TODO Auto-generated method stub
		int height = grid.length;
		int width = grid[0].length;
		
		for(int i = 0; i < height; i++) {
			for(int j = 0; j < width; j++) {
				System.out.print(grid[i][j] + " ");
			}
			System.out.println("");
		}

	}

	
	/*
	 * init - initialize the grid with '-'. 
	 */
	private void init(char[][] grid) {
		// TODO Auto-generated method stub
		int height = grid.length;
		int width = grid[0].length;
		for(int i = 0; i < height; i++) {
			for(int j = 0; j < width; j++) {
				grid[i][j] = '-';
			}
		}
	}

}
