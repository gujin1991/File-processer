/*
 * Class which all different formats will be change into.
 * Encapsulating the product information.
 */

public class Product {
	private String supplierID;
	private String productID;
	private long quantity;
	
	public Product(String supplierID, String productID, long quantity) {
		
	}
	
	String getSupplierID() {
		return "";
	}
	
	String getProductID() {
		return "";
	}
	
	long getQuantity() {
		return 0;
		
	}
	
	void updateSupplierID(String supplierID) {
		
	}
	void updateProductID(String productID) {
		
	}
	void updateQuantity(long quantity) {
		
	}

}
